var Adoption = artifacts.require("Adoption");
var TicketManager = artifacts.require("TicketManager");
module.exports = function(deployer) {
  deployer.deploy(Adoption);
};

module.exports = function(deployer) {
  deployer.deploy(TicketManager);
};