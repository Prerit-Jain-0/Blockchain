App = {
  web3Provider: null,
  contracts: {},

  init: async function () {
    // Load pets.
    
    App.loadSearchFlights()
    App.mybookingFlights()
   

    return await App.initWeb3();
  },

  

  loadSearchFlights:function(){
    $.getJSON('../searchflights.json', function (data) {
      var flightRow = $('#searchFlightRow');
      var flightTemplate = $('#searchFlightTemplate');

      for (i = 0; i < data.length; i++) {
        flightTemplate.find('.panel-title').text(data[i].name);
        flightTemplate.find('img').attr('src', data[i].picture);
        flightTemplate.find('.air-date').text(data[i].date);
        flightTemplate.find('.air-from').text(data[i].from);
        flightTemplate.find('.air-to').text(data[i].to);
        flightTemplate.find('.btn-adopt').attr('data-id', data[i].id);
        flightTemplate.find('.loadflights').attr('data-id', data[i].name);

        flightTemplate.find('.numtkts').attr('max', data[i].avltkts);
        flightTemplate.find('.air-avltkts').text(data[i].avltkts)
        flightRow.append(flightTemplate.html());
      }
    });
  },

  mybookingFlights:function(){
    $.getJSON('../mybooking.json', function (data) {
      var flightRow = $('#mybookingFlighttRow');
      var flightTemplate = $('#mybookingFlightTemplate');

      for (i = 0; i < data.length; i++) {
        flightTemplate.find('.panel-title').text(data[i].name);
        flightTemplate.find('img').attr('src', data[i].picture);
        flightTemplate.find('.air-date').text(data[i].date);
        flightTemplate.find('.air-from').text(data[i].from);
        flightTemplate.find('.air-to').text(data[i].to);
        flightTemplate.find('.air-bookkts').text(data[i].bookedtkts);
        flightTemplate.find('.btn-adopt').attr('data-id', data[i].id);


        flightRow.append(flightTemplate.html());
      }
    });
  },




  initWeb3: async function () {
    // Modern dapp browsers...
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        // Request account access
        await window.ethereum.request({ method: "eth_requestAccounts" });;
      } catch (error) {
        // User denied account access...
        console.error("User denied account access")
      }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
    }
    // If no injected web3 instance is detected, fall back to Ganache
    else {
      App.web3Provider = new Web3.providers.HttpProvider('http://3.84.100.30:8547');
    }
    web3 = new Web3(App.web3Provider);
    web3.eth.getBalance(web3.eth.accounts[0], function (error, result) {
      if (!error) {
        console.log(web3.eth.accounts[0] + ': ' +web3.fromWei(result));
        var accountTemplate = $('#myaccounttemplate');
        accountTemplate.find('.my-account-balance').text(web3.fromWei(result));
        accountTemplate.find('.my-account-number').text(web3.eth.accounts[0]);

        
      };
    });
   // console.log('balance', web3.fromWei(web3.eth.getBalance(web3.eth.accounts[0])));
    return App.initContract();
  },

  initContract: function () {
    

    $.getJSON('TicketManager.json', function(data) {
      // Get the necessary contract artifact file and instantiate it with @truffle/contract
      var TicketMangerArtifact = data;
      App.contracts.TicketManager = TruffleContract(TicketMangerArtifact);
    
      // Set the provider for our contract
      App.contracts.TicketManager.setProvider(App.web3Provider);
    
      // Use our contract to retrieve and mark the adopted pets
      //return App.markAdopted();
    });
    return App.bindEvents();
  },

  
  bindEvents:function(){
    $(document).on('click','.btn-cancelflights',App.cancelFlights);
    $(document).on('click','.btn-loadflight',App.loadFlights);
  },


  loadFlights:function(event){
      console.log('this loads flight',$(event.target).data)
      var ticketManagerInstance;

      web3.eth.getAccounts(function(error, accounts) {
        if (error) {
          console.log(error);
        }
      
        var account = accounts[0];

        web3.eth.defaultAccount=web3.eth.accounts[0]


        var dt = Math.floor((new Date()).getTime() / 1000)
        App.contracts.TicketManager.deployed().then(function(instance) {
          ticketManagerInstance = instance;
          
          // Execute adopt as a transaction by sending account
          return ticketManagerInstance.add_flight(
            flight_id_ = '0x78afef6b05f41bc1bb14ccee8b253c737ccf4e9d76f33a1c56ca342a2bd580ed',
            flight_time_ = dt,
            total_seats_ = 100,
            price_per_seats_ = 30000
            );

        }).then(function(result) {
          console.log(result);
        }).catch(function(err) {
          console.log(err.message);
        });
      });

  },
  

  cancelFlights:function(event){
    console.log('this loads flight',$(event.target).data)
    var ticketManagerInstance;

    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
      }
    
      var account = accounts[0];

      web3.eth.defaultAccount=web3.eth.accounts[0]


      var dt = Math.floor((new Date()).getTime() / 1000)
      App.contracts.TicketManager.deployed().then(function(instance) {
        ticketManagerInstance = instance;
        
        // Execute adopt as a transaction by sending account
        return ticketManagerInstance.cancel_flight(
          flight_id_ = '0x78afef6b05f41bc1bb14ccee8b253c737ccf4e9d76f33a1c56ca342a2bd580ed',
          now_=dt);

      }).then(function(result) {
        console.log(result);
      }).catch(function(err) {
        console.log(err.message);
      });
    });

},
  

};

$(function () {
  $(window).load(function () {
    App.init();
  });

});

function goNext(){
  $('#searchFlightRow').show()
  $('#previous').show()
  $('#searchFlightRowForm').hide()
} 

function goPrevious(){
  $('#searchFlightRow').hide()
  $('#previous').hide()
  $('#searchFlightRowForm').show()
} 


